-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 28, 2023 at 10:41 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tms`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(30) NOT NULL,
  `studentname` varchar(50) DEFAULT NULL,
  `coursename` varchar(50) DEFAULT NULL,
  `duration` varchar(30) DEFAULT NULL,
  `batchattended` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `studentname`, `coursename`, `duration`, `batchattended`) VALUES
(5, 'anitha', 'lamp stack', '4month', '3rd batch'),
(8, 'renuka', 'back end', '5 month', '5th batch'),
(10, 'keerthi A', 'lamp stack', '3month', '4th batch'),
(11, 'roshni A', 'Full stack', '5month', '3rd batch');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `course_id` int(30) NOT NULL,
  `newcourse` varchar(50) DEFAULT NULL,
  `package` varchar(50) DEFAULT NULL,
  `duration` varchar(30) DEFAULT NULL,
  `currentdate` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`course_id`, `newcourse`, `package`, `duration`, `currentdate`) VALUES
(19, 'frontend', 'remote', '3month', '08-09-2023'),
(22, 'fullstack', 'remote', '4month', '09-09-2023'),
(23, 'frontend', 'remote', '4month', '05-04-2023'),
(24, 'fullstack', 'remote', '4month', '09-09-2023'),
(25, 'backend', 'remote', '4month', '08-09-2023'),
(29, 'backend', 'remote', '8 month', '01-07-2023'),
(30, 'fullstack', 'remote', '4month', '08-09-2023');

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `emp_id` int(30) NOT NULL,
  `facultyname` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `phonenumber` int(30) DEFAULT NULL,
  `emailid` varchar(30) DEFAULT NULL,
  `joiningdate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`emp_id`, `facultyname`, `address`, `phonenumber`, `emailid`, `joiningdate`) VALUES
(1, '', '', 0, '', '0000-00-00'),
(5, '', '', 0, '', '0000-00-00'),
(11, 'meera', '', 0, 'meera', '2023-10-12'),
(13, 'malathi', '', 0, 'malathi', '2023-10-05'),
(14, 'hema', '', 0, 'hema', '2023-09-27'),
(15, 'sheeba', '', 0, 'sheeba', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `id` int(30) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `phonenumber` int(30) DEFAULT NULL,
  `batch` varchar(30) DEFAULT NULL,
  `course` varchar(30) DEFAULT NULL,
  `monthlyfee` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`id`, `name`, `address`, `phonenumber`, `batch`, `course`, `monthlyfee`) VALUES
(1, '', 'dubai', 9088545, '2nd', 'fullstack', '9000'),
(14, '', 'trichy', 8092255, '4th batch', 'fullstack', '9000'),
(15, '', 'chennai', 8092255, '2nd', 'backend', '9000');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(30) NOT NULL,
  `feeupdation` varchar(50) DEFAULT NULL,
  `respectivecourses` varchar(50) DEFAULT NULL,
  `feecollected` varchar(50) DEFAULT NULL,
  `feedefaulter` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `feeupdation`, `respectivecourses`, `feecollected`, `feedefaulter`) VALUES
(1, '', '', '', ''),
(5, '6k more', 'back end', 'pending 6k', 'done');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(30) NOT NULL,
  `studentname` varchar(50) DEFAULT NULL,
  `studentage` int(30) DEFAULT NULL,
  `studentaddress` varchar(50) DEFAULT NULL,
  `fathername` varchar(30) DEFAULT NULL,
  `fathermailid` varchar(50) DEFAULT NULL,
  `phonenumber` int(30) DEFAULT NULL,
  `coursechoosen` varchar(60) DEFAULT NULL,
  `proof` int(30) DEFAULT NULL,
  `date` varchar(33) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `studentname`, `studentage`, `studentaddress`, `fathername`, `fathermailid`, `phonenumber`, `coursechoosen`, `proof`, `date`) VALUES
(44, 'hema', 20, 'tirunelveli', 'vimal', 'vimal@gmail.com', 80997444, 'fornt end', NULL, '2023-09-27'),
(49, 'priya v', 23, 'chennai', 'vijay', 'vijay@gmail.com', 809333, 'back end', 0, '2023-10-06'),
(53, 'sweety S', 21, 'tirunelveli', 'sanjay', 'sanjay@gmail.com', 8092254, 'back end', 0, '2023-10-28');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`course_id`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`emp_id`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `course_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `faculty`
--
ALTER TABLE `faculty`
  MODIFY `emp_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `invoice`
--
ALTER TABLE `invoice`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
